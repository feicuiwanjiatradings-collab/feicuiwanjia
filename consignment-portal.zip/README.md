# Consignment Portal (寄卖商品门户)

这是一个简单的网页应用，允许多个顾客仅查看自己的寄卖商品。  
管理员可以通过密钥管理所有数据并为顾客生成专属链接。

## ✨ 功能
- 顾客通过专属链接（`?key=顾客密钥`）只能看到自己的寄卖商品  
- 管理员入口：`?key=admin-12345`  
- 支持上传 CSV/JSON 管理商品（可扩展）  
- 数据保存到浏览器 LocalStorage（可扩展）  
- 可打印或导出 PDF（浏览器打印功能）

## 🚀 部署到 GitHub Pages
1. 新建一个 GitHub 仓库，例如：`consignment-portal`  
2. 上传本项目中的文件（至少需要 `index.html` 和 `README.md`）  
3. 进入仓库 **Settings → Pages**  
   - 在 *Branch* 中选择 `main` 分支  
   - 选择 `/ (root)` 路径  
   - 点击 **Save**  
4. 过几分钟后，你会获得一个网址，例如：  
   ```
   https://你的用户名.github.io/consignment-portal/
   ```

## 🔑 使用方式
- 管理员登录  
  ```
  https://你的用户名.github.io/consignment-portal/?key=admin-12345
  ```

- 顾客登录  
  ```
  https://你的用户名.github.io/consignment-portal/?key=cust-001
  ```

## 🛠 修改管理员密钥
1. 打开 `index.html`  
2. 搜索 `admin-12345` 并替换为你自己的新密钥  
3. 保存并重新部署到 GitHub
